import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  private intro;
  private inputValue = 'Enter text here';
  private userInput;
  private showUserInput = false;

  public constructor(){
    this.intro = 'Template Reference Variable Demo';
  }
  public clickHandler(inputElem) {
    console.log(inputElem.value);
    this.showUserInput = true;
    this.userInput = inputElem.value;
    setTimeout(() => this.showUserInput = false, 3000);
  }

}
